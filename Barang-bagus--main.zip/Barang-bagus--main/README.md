Barang bagus 
